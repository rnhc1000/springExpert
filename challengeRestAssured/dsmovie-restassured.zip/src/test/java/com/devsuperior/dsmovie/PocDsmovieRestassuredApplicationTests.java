package com.devsuperior.dsmovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocDsmovieRestassuredApplicationTests {

	@Test
	void contextLoads() {
	}

}
