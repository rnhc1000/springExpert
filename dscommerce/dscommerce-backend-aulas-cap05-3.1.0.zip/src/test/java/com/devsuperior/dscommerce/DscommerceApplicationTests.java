package com.devsuperior.dscommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DscommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
